pub use persist::{persist_delete_prop, persist_get_prop, persist_get_props, persist_set_prop};

mod persist;
mod proto;
